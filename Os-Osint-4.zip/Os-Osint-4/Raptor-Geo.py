import requests
from rich.console import Console
from rich.table import Table
from geopy.geocoders import Nominatim
from geopy.exc import GeocoderTimedOut, GeocoderServiceError
from rich.text import Text

console = Console()


def print_banner():
    banner = """
⡀⠀⠀⠀⠀⠀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡠⠀
⠈⣦⡀⠀⠀⠀⠀⠙⢶⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣤⠖⢂⡞⠀⠀
⠀⣼⡇⠀⠀⠀⠀⠀⠈⣿⣆⠀⠀⢀⡴⠋⠀⠀⣰⣿⠁⠀⢸⣧⠀⠀
⢠⣿⡇⠀⠀⠀⠀⠀⠀⣿⠿⠀⢀⣿⠃⠀⠀⢰⣿⡏⠀⠀⢸⣿⣄⠀
⣪⣷⡆⠀⠀⠀⠀⢀⣜⡛⡟⠀⠸⣟⡆⠀⠀⠘⣛⡳⠀⠀⠈⣿⣿⡄
⢟⣭⣷⡀⠀⠀⢀⣯⣟⡟⠀⠀⠀⠟⣽⡧⠀⢸⣟⠻⡆⠀⠀⢰⣦⣝
⠸⡟⣿⡿⣦⠀⠟⠉⡉⣠⡦⣠⡷⠀⡵⠟⢃⣼⡿⣿⠀⠀⢀⣾⣛⠿    ________               __________                __            
⠀⠀⠻⠇⢿⠀⡆⢾⠃⠛⠡⣉⣠⣤⣤⣶⣿⢹⣿⠈⠀⢀⣼⡿⣿⡆   /  _____/  ____  ____   \______   \_____  _______/  |_  ___________    
⠀⠀⠀⠀⢀⣼⣿⣌⠀⢰⢤⣄⡉⠛⠉⣚⠋⢈⣁⣠⣴⡟⣿⣧⠸⠃ /   \  ____/ __ \/  _ \   |       _/\__  \ \____ \   __\/  _ \_  __ \
⠀⠀⠀⠀⢸⡿⠿⠻⠷⠄⢱⣄⠈⠻⠿⠿⠟⣻⣿⠏⣿⡇⢸⠏⠀⠀ \    \_\  \  ___(  <_> )  |    |   \ / __ \|  |_> >  | (  <_> )  | \/
⠀⠀⠀⠀⣸⡷⠀⠀⣠⣴⣧⠙⣷⣤⡀⠚⠿⠿⠋⠰⠛⠁⠀⠀  ⠀⠀\______  /\___  >____/   |____|_  /(____  /   __/|__|  \____/|__|   
⠀⠀⢀⣾⣿⣿⣾⣿⣿⣿⡿⠀⠈⢿⣿⡆⠀⠱⣶⣾⣷⡀⠀⠀⠀       ⠀ \/     \/                \/      \/|__|         
⠀⠀⠈⢹⣿⣿⣿⣿⡿⠋⠁⠀⡀⠈⠻⣿⣦⠀⠈⠻⣿⣿⣦⡀⠀⠀                        
⠀⠀⠀⠠⣭⣿⣿⣿⣴⣶⣶⣿⠁⠀⠀⠘⢿⣧⠀⠀⠙⣿⣿⠻⣦⠀
⠀⠀⠀⠀⣾⣿⣿⣿⠿⠟⠛⠁⠀⠀⠀⠀⠘⣿⡄⠀⠀⠹⣿⣧⠈⢣
⠀⠀⠀⠀⠈⠉⠁⠀⢰⣄⠀⠀⠀⢢⠀⠀⠀⢸⡇⠈⡀⠀⢿⣿⡆⠀    
⠀⠀⠀⠀⠀⠀⠀⣠⣿⣿⣷⡀⠀⠈⡇⠀⠀⢸⠇⢰⡇⠀⣼⣿⡇  
⠀⠀⠀⠀⠀⢠⣾⠟⡛⠛⠛⢇⠀⣸⡗⠀⠀⠘⢀⣾⠇⢀⣿⣿⠃⠀
⠀⠀⠀⠀⠀⡿⠁⣼⡀⠀⠀⢀⣴⣿⠃⠀⠀⢁⣾⡿⢀⣾⣿⠏⠀⠀
⠀⠀⠀⠀⠀⠇⠀⠈⠻⢶⡾⠿⠛⠁⠀⣀⣴⣿⣿⣶⣿⣿⠋⠀⠀⠀
⠀⠀⠀⣠⣶⡿⣿⣿⣶⣦⣴⣦⣶⣶⣿⣿⣿⣿⣿⠿⠋⠀⠀⠀⠀⠀
⠀⠀⠀⣿⠀⠀⠀⠀⠈⠙⠛⠻⠟⠿⠻⠛⠛⠉⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠈⠀⠀⠀⠀
    """

    console.print(f"[bold cyan]{banner}[/bold cyan]")
    console.print(f"[bold red]Creator Sakuta[/bold red]")
    console.print("[bold green]Добро пожаловать в Геосервис... поиск активирован![/bold green]")
def format_location(address):
    if not address or address == "Местоположение не найдено.":
        console.print("[red]Местоположение не найдено.[/red]")
        return
    parts = [part.strip() for part in address.split(",")]
    keys = [
        "Улица",
        "Район",
        "Город",
        "Округ",
        "Область",
        "Федеральный округ",
        "Почтовый индекс",
        "Страна"
    ]
    table = Table(title="Детальная информация о месте", style="cyan")
    table.add_column("[bold]Категория[/bold]", justify="left", style="green")
    table.add_column("[bold]Значение[/bold]", justify="left", style="yellow")
    for i, part in enumerate(parts):
        if part and part.lower() != "неизвестно": 
            key = keys[i] if i < len(keys) else f"Дополнительно {i - len(keys) + 1}"
            table.add_row(f"[green]{key}[/green]", f"[yellow]{part}[/yellow]")
    console.print(table)
def get_location_data(latitude, longitude):
    geolocator = Nominatim(user_agent="GeoServiceApp")
    try:
        location = geolocator.reverse((latitude, longitude), exactly_one=True)
        return location.address if location else "Местоположение не найдено."
    except GeocoderTimedOut:
        return "Запрос тайм-аут. Пожалуйста, попробуйте позже."
    except GeocoderServiceError as e:
        return f"Ошибка сервиса геокодирования: {e}"
def get_exact_location(lat, lon):
    url = f"https://geocode.xyz/{lat},{lon}?geoit=json"
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        data = response.json()
        if "error" in data:
            raise Exception("Ошибка GeoCode.xyz: " + data["error"]["description"])
        location = {
            "Ответ с GeoCode:": "",
            "Country": data.get("country", "Неизвестно"),
            "State": data.get("state", "Неизвестно"),
            "City": data.get("city", "Неизвестно"),
            "Postcode": data.get("postal", "Неизвестно"),
            "Road": data.get("staddress", "Неизвестно"),
            "House_number": data.get("stnumber", "Неизвестно"),
        }
        return location
    except Exception as e:
        console.print(f"[red]Ошибка получения точного адреса: {e}[/red]")
        return {}
def get_nearby_places(lat, lon, radius=100):
    overpass_url = "http://overpass-api.de/api/interpreter"
    query = f"""
    [out:json];
    (
      node(around:{radius},{lat},{lon});
      way(around:{radius},{lat},{lon});
      relation(around:{radius},{lat},{lon});
    );
    out center;
    """
    try:
        response = requests.post(overpass_url, data={"data": query}, timeout=20)
        response.raise_for_status()
        data = response.json()
        results = []
        for element in data.get("elements", []):
            name = element.get("tags", {}).get("name", "Неизвестно")
            element_type = element.get("tags", {}).get("amenity", "Неизвестно")
            coords = element.get("lat"), element.get("lon") if "lat" in element else element.get("center", {})
            if not name or name.lower() == "неизвестно" or not coords:
                continue
            
            results.append({"name": name, "type": element_type.capitalize(), "coordinates": coords})
        return results
    except Exception as e:
        console.print(f"[red]Ошибка получения ближайших объектов: {e}[/red]")
        return []
def display_exact_location(location):
    console.print("\n[bold magenta]Точная информация о месте:[/bold magenta]\n")
    for key, value in location.items():
        console.print(f"[green]{key}:[/green] {value}")
def display_nearby_places(places):
    console.print("\n[bold magenta]Ближайшие объекты:[/bold magenta]\n")
    table = Table(title="Ближайшие объекты", show_lines=True)
    table.add_column("Название", justify="left", style="green")
    table.add_column("Тип", justify="center", style="cyan")
    table.add_column("Координаты", justify="right", style="yellow")
    if places:
        for place in places:
            table.add_row(
                place["name"],
                place["type"],
                f"{place['coordinates']}" if place["coordinates"] else "Не указано"
            )
    else:
        table.add_row("Ничего не найдено", "-", "-")
    console.print(table)
def generate_html(exact_location, location_data, nearby_places):
    html_content = f"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Geo Raptor - Результаты Осинтера</title>
        <style>
            body {{
                background-color: #1a1a1a;
                color: #00ff00;
                font-family: 'Courier New', Courier, monospace;
                font-size: 18px;
                text-align: center;
                padding: 50px;
            }}
            h1 {{
                border: 3px solid #00ff00;
                padding: 15px;
                border-radius: 5px;
                text-transform: uppercase;
                letter-spacing: 2px;
            }}
            h2 {{
                color: #ff0000;
                margin-top: 30px;
                text-transform: uppercase;
            }}
            ul {{
                list-style-type: none;
                padding: 0;
            }}
            li {{
                margin: 15px 0;
                font-weight: bold;
            }}
            .geo-info {{
                background-color: #333333;
                padding: 10px;
                border-radius: 5px;
            }}
            .nearby {{
                background-color: #444444;
                padding: 10px;
                border-radius: 5px;
            }}
        </style>
    </head>
    <body>
        <h1>Geo Raptor - Результаты Осинтера</h1>
        <div class="geo-info">
            <ul>
                <li><b>Точное местоположение:</b> {location_data}</li>
                <li><b>Ответ с GeoCode:</b></li>
                <ul>
    """
    for key, value in exact_location.items():
        html_content += f"<li>{key}: {value}</li>"
    html_content += """
                </ul>
            </ul>
        </div>
        <h2>Ближайшие объекты:</h2>
        <div class="nearby">
            <ul>
    """
    for place in nearby_places:
        html_content += f"<li>{place['name']} ({place['type']}) - {place['coordinates']}</li>"
    html_content += """
            </ul>
        </div>
    </body>
    </html>
    """
    with open("geo_raptor_results.html", "w") as file:
        file.write(html_content)
def cords():
    print_banner()
    console.print("[bold blue]Введите координаты:[/bold blue]")
    try:
        lat = float(console.input("[blue]Широта: [/blue]"))
        lon = float(console.input("[blue]Долгота: [/blue]"))
    except ValueError:
        console.print("[red]Ошибка ввода координат. Попробуйте еще раз.[/red]")
        return
    console.print(f"\n[cyan]Ищем информацию о месте с координатами: {lat}, {lon}...[/cyan]")
    exact_location = get_exact_location(lat, lon)
    display_exact_location(exact_location)
    location_data = get_location_data(lat, lon)
    console.print("\n[bold magenta]Ответ от парсера:[/bold magenta]\n")
    format_location(location_data)
    places = get_nearby_places(lat, lon)
    display_nearby_places(places)
    generate_html(exact_location, location_data, places)
    print("Результаты успешно сохранены в Raptor-results.html")
cords()
